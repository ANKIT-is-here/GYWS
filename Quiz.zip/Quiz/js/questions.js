
let questions = [
  {
    numb: 1,
    question: "What is the primary goal of an NGO (Non-Governmental Organization)?",
    answer: "Social service",
    options: [
      "Profit-making",
      "Social service",
      "Political influence",
      "Business expansion"
    ]
  },
  {
    numb: 2,
    question: "Which of the following is a common focus area for many NGOs?",
    answer: "All of the above",
    options: [
      "Education",
      "Environmental protection",
      "Healthcare",
      "All of the above"
    ]
  },
  {
    numb: 3,
    question: "Which famous Indian personality is known for their work in promoting education among underprivileged children?",
    answer: "Kailash Satyarthi",
    options: [
      "Mother Teresa",
      "Kailash Satyarthi",
      "Aruna Roy",
      "Kiran Bedi"
    ]
  },
  {
    numb: 4,
    question: "What does the term 'sustainable development' refer to?",
    answer: "Development that meets the needs of the present without compromising the ability of future generations to meet their own needs",
    options: [
      "Economic growth without environmental considerations",
      "Development that meets the needs of the present without compromising the ability of future generations to meet their own needs",
      "Rapid industrialization",
      "None of the above"
    ]
  },
  {
    numb: 5,
    question: "Which of the following is a major issue that NGOs work to address?",
    answer: "All of the above",
    options: [
      "Child labor",
      "Poverty",
      "Gender inequality",
      "All of the above"
    ]
  }



];